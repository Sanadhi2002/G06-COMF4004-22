﻿namespace AuthProject.Models
{
    public class VMLogin
    {
        public string Email { get; set; }
        public string PassWord { get; set; }
        public bool KeepLoggedIn { get; set; }
    }
}
