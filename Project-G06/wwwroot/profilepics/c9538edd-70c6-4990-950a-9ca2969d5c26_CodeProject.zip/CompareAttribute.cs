// Author - Karthikeyan Arunachalam

using System;

namespace CodeProject
{
	/// <summary>
	/// Use this attribute to decorate properties, which you want to compare among objects.
	/// Only properties marked with this attribute will be displayed in the final output.
	/// </summary>
	[AttributeUsage(AttributeTargets.Property)]
    public class CompareAttribute : System.Attribute
    {
        private int __displayOrder = 0;
        private string __displayName = string.Empty;
		
        /// <param name="DisplayOrder">The properties will be listed in the comparison table based on the display order.
        /// No two properties can have the same display order. Property with a display order of 5 will appear before 
        /// the property with a display order of 10.</param>
        /// <param name="DisplayName">Detailed description of the property being compared.</param>
        public CompareAttribute(int DisplayOrder, string DisplayName)
        {
            __displayOrder = DisplayOrder;
            __displayName = (DisplayName == null) ? "<undefined>" : DisplayName.Trim();
        }
		
        public int DisplayOrder
        {
            get
            {
                return __displayOrder;
            }
        }

        public string DisplayName
        {
            get
            {
                return __displayName;
            }
        }
    }
}
