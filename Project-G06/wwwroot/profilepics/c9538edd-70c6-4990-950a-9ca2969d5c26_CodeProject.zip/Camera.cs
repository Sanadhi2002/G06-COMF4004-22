// Author - Karthikeyan Arunachalam

using System;

namespace CodeProject
{
	public class Camera
	{
		private string __name;
		private string __model;
		private double __price;
		private string __warranty;
		private bool __carlZeiss;

        public Camera()
        {
            __name = string.Empty;
            __model = string.Empty;
            __price = 0.0;
            __warranty = string.Empty;
            __carlZeiss = false;
        }

        public Camera(string Name, string Model, double Price, string Warranty, bool CarlLens)
        {
            this.Name = Name;
            this.Model = Model;
            this.Price = Price;
            this.Warranty = Warranty;
            this.HasCarlZeiss = CarlLens;
        }

		[Compare(1, "Name")]
		public string Name
		{
			get
			{
				return __name;
			}
			set
			{
				__name = (value == null) ? string.Empty : value.Trim();
			}
		}

		[Compare(2, "Model")]
		public string Model
		{
			get
			{
				return __model;
			}
            set
            {
                __model = (value == null) ? string.Empty : value.Trim();
            }
		}


        [Compare(5, "Warranty Info")]
        public string Warranty
        {
            get
            {
                return __warranty;
            }
            set
            {
                __warranty = (value == null) ? string.Empty : value.Trim();
            }
        }

		[Compare(4, "Carl Zeiss Lens")]
		public bool HasCarlZeiss
		{
			get
			{
				return __carlZeiss;
			}
			set
			{
				__carlZeiss = value;
			}
		}

        [Compare(3, "List Price")]
        public double Price
        {
            get
            {
                return __price;
            }
            set
            {
                __price = value;
            }
        }
	}
}
