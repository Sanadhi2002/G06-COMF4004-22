// Author - Karthikeyan Arunachalam
using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CodeProject
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Table Table1;
        protected DiffTable ctlDiffTable;

		private void Page_Load(object sender, System.EventArgs e)
		{
            if(!IsPostBack)
            {
                //In real scenario, you will be creating multiple instances of objects of the same type to be compared
                // and assign it to the ObjectsToCompare property of the DiffTabel User control.
                Camera cam1 = new Camera("MVC-FD200 FD Mavica�", "MVCFD200KITIS", 299.95, "1 Year parts, 30 days labor", true);
                Camera cam2 = new Camera("MVC-CD500 CD Mavica�", "MVCCD500KITIS", 699.95, "1 Year parts, 60 days labor", true);
                Camera cam3 = new Camera("MVC-CD350 CD Mavica�", "MVCCD350KITIS", 399.95, "1 Year parts, 90 days labor", true);

                ArrayList cameras = new ArrayList(3);
                cameras.Add(cam1);
                cameras.Add(cam2);
                cameras.Add(cam3);

                ctlDiffTable.ObjectsToCompare = cameras;
            }
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
