using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;
using System.Reflection;
using System.ComponentModel;

namespace CodeProject
{
	/// <summary>
	/// Summary description for DiffTable.
	/// </summary>
	[DefaultProperty("Text"), ToolboxData("<{0}:DiffTable runat=server></{0}:DiffTable>")]
	public class DiffTable : Control
	{
        private ArrayList __objectsToCompare;
        protected Table tblCompare;

        public DiffTable()
        {
            tblCompare = new Table();
            tblCompare.GridLines = GridLines.Both;
        }

        public ArrayList ObjectsToCompare
        {
            set
            {
                __objectsToCompare = value;
            }
        }

        /// <summary>
        /// Loops thru each object in the arraylist and verifies whether all the objects are of the same type or not.
        /// </summary>
        /// <param name="Objects">Contains the list of objects to be compared.</param>
        private void VerifyObjectTypes(ArrayList Objects)
        {
            for(int i = 0; i < Objects.Count; i++)
            {
                if(Objects[0].GetType() != Objects[i].GetType())
                    throw new Exception(string.Format("All objects to be compared must be of the same type."));		
            }
        }

        /// <summary>
        /// Identifies the list of properties which are decorated with the custom attribute "Compare".
        /// </summary>
        /// <param name="type">Type of the objects being compared.</param>
        /// <returns>Only properties which are marked with CompareAttribute.</returns>
        private SortedList FetchComparableProperties(Type type)
        {
            SortedList prps = new SortedList(32);
            CompareAttribute cmp = null;
			
            foreach(PropertyInfo prpInfo in type.GetProperties())
            {
                cmp = (CompareAttribute)Attribute.GetCustomAttribute(prpInfo, typeof(CompareAttribute));
                if(cmp != null)
                {
                    if(prps.ContainsKey(cmp.DisplayOrder))
                        throw new Exception(string.Format("A property with the same display order of {0} already exists.", cmp.DisplayOrder));
                    prps.Add(cmp.DisplayOrder, prpInfo);
                }
            }

            return prps;
        }

        /// <summary>
        /// Using Reflection, renders the comparable properties and the values of all the objects for each
        /// property in a tabular format. The prooerties are displayed using the display order specified in the
        /// CompareAttribute.
        /// </summary>
        /// <param name="Objects">Contains the objects that are submitted for comparison.</param>
        private void Compare(ArrayList Objects)
        {
            SortedList properties = FetchComparableProperties(Objects[0].GetType());

            CompareAttribute cmp = null;

            foreach(PropertyInfo prpInfo in properties.Values)
            {
                bool captionFetched = false;
                TableRow row = null;
                TableCell cell = null;

                foreach(object obj in Objects)
                {
                    cmp = (CompareAttribute)Attribute.GetCustomAttribute(prpInfo, typeof(CompareAttribute));
                    if(cmp != null)
                    {
                        if(!captionFetched)
                        {
                            row = new TableRow();
                            cell = new TableCell();

                            cell.Text = cmp.DisplayName;
							cell.BackColor = System.Drawing.Color.FromArgb(0xff, 0xff, 0xcc);
                            row.Cells.Add(cell);
                            tblCompare.Rows.Add(row);
                            captionFetched = true;
                        }
                        cell = new TableCell();
                        cell.Text = prpInfo.GetValue(obj, null).ToString();
                        row.Cells.Add(cell);
                    }
                }
            }
        }
        
        protected override void Render(HtmlTextWriter output)
		{
            // THere should be atleast 2 objects to make a comparison table.
            if(__objectsToCompare.Count < 2)
                throw new Exception("Please provide a minimum of 2 objects to create comparison table.");

            //All the objects to be compared must be of the same type.
            VerifyObjectTypes(__objectsToCompare);

            Compare(__objectsToCompare);

            tblCompare.RenderControl(output);
        }
	}
}
