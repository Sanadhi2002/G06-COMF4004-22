﻿namespace Dotnet6MvcLogin.Models.DTO
{
    public class Status
    {
        public int StatusCode { get; set; }
        public string Message { get; set; }
    }
}
